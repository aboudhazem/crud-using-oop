<?php include('header.php'); ?>
<?php  $page_active = "home"; ?>
<?php include('nav.php'); ?>





<div class="container">
    <div class="row">
        <div class="col-sm-12">
            <h2 class="p-3 col text-center mt-5 text-white bg-primary">  Welcome </h2>
        </div>

     
        
        
        
    </div>
</div>


<?php include('footer.php'); ?>



  
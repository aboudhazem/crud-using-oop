  <!-- Latest compiled and minified JavaScript -->
  <script src="./js/jquery-3.3.1.slim.min.js" ></script>
    <script src="./js/popper.min.js" ></script>
    <script src="./js/bootstrap.min.js" ></script>
    <script src="./js/a4794b9b18.js" ></script>
</body>
</html>